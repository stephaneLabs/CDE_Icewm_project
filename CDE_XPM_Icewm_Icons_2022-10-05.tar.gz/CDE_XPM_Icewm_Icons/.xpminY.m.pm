/* XPM */
/* $XConsortium: FpminY.m.pm /main/3 1995/07/18 17:00:39 drk $ */
/*********************************************************************
*  (c) Copyright 1993, 1994 Hewlett-Packard Company	
*  (c) Copyright 1993, 1994 International Business Machines Corp.
*  (c) Copyright 1993, 1994 Sun Microsystems, Inc.
*  (c) Copyright 1993, 1994 Unix System Labs, Inc., a subsidiary of
*      Novell, Inc.
**********************************************************************/

static char * Fminsel [] = {
/* width height ncolors cpp [x_hot y_hot] */
"17 12 4 1 0 0",
/* colors */
"     s bottomShadowColor m black c #636363636363",
".    s topShadowColor m white c #bdbdbdbdbdbd",
"X    s selectColor m white c #737373737373",
"o    s background    m black c #949494949494",
/* pixels */
"                .",
"  XXXXXXXXXXXXXX.",
"  XXXXXXXXXXXXXX.",
"  XXXXXXXXXXXXXX.",
"  XXXXX....XXXXX.",
"  XXXXX.oo XXXXX.",
"  XXXXX.oo XXXXX.",
"  XXXXX.   XXXXX.",
"  XXXXXXXXXXXXXX.",
"  XXXXXXXXXXXXXX.",
"  XXXXXXXXXXXXXX.",
"  ..............."};
