Iconset based on 'CDE icons' a KDE iconset made by Arenyart (Andrew Enyart Atlanta, United States of America).
See :https://www.gnome-look.org/p/1120392/

It's not perfect, and has been tested on PCManFM. It loosely works, the icons are OK but arrows but the theme does not manage the navigating arrows next to the address bar. Maybe it should be managed at the GTK theme level more than at the icons theme level.

The work mainly consisted in copying some icons, and renaming other to be freedesktop compliant.

Changelog :
I have made some simple navigating arrows that are quite acceptable and made some consistant work on the icons name and folders. 
I may work very well with pcmanfm and suits your icewm menu if you use names according to FreeDesktop icons naming,
see : https://specifications.freedesktop.org/icon-naming-spec/icon-naming-spec-latest.html

I have used icewm-menu-fdo to create my menu, it respect FreeDesktop naming but to me it creates too long paths to get to an application.
So I simplified the config file by hand. It's quite easy to get something really efficient.

Stéphane
10 03 2022
